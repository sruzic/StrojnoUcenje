real_labels = load('test-label.dat');
infered_labels = load('inf-labels20.dat');

conf=zeros(8,8);
for i = 1:800
	conf(real_labels(i)+1,infered_labels(i)+1)++;
end
conf
precision=zeros(8,1);
for i = 1:8
	precision(i)=conf(i,i)/sum(conf(:,i));
end
recall=zeros(8,1);
for i = 1:8
	recall(i)=conf(i,i)/sum(conf(i,:));
end
precision
recall
avg_precision=sum(precision(:))/8
